#include "LinkedList.h"

int main(){
    LinkedList lList(1);    
    printf("Inserting 5\n");
    lList.insert(5);
    printf("Printing List\n");
    lList.print();
    return 1;
}
